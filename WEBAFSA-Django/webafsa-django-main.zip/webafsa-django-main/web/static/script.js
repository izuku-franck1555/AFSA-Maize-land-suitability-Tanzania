function resetMap() {
    map.eachLayer(function (layer) {
        map.removeLayer(layer);
    });

    map.eachLayer(function (layer) {
        if (layer instanceof L.Marker) {
            map.removeLayer(layer);
        }
    });

    map.setView([7.3697, 12.3547], 4)
}

function generateUniqueID() {
    const now = new Date();
    const timestamp = now.getTime();
    return timestamp.toString();
}

var checkboxs = document.querySelectorAll("input[type='checkbox']");
var new_marker = null;
var reference_site_marker = null;

checkboxs.forEach(function (checkbox) {
    checkbox.addEventListener("click", function () {
        const checkboxName = $(this).attr('name');
        const textFieldName = $(this).data('textfield');
        const isChecked = $(this).is(':checked');
        $('input[name="' + textFieldName + '"]').prop('disabled', !isChecked)
    });
});

$('#compute-similarity').click(function () {
    $('#map').hide();
    $('.loader').show();

    var request_id = generateUniqueID();
    var dataset = $('input[name="climate_dataset"]:checked').val();
    var longitude = parseFloat($('#long').val());
    var latitude = parseFloat($('#lat').val());
    var env_vars = [];
    var weights = [];
    $('input[type="checkbox"]:checked').each(function () {
        var variableName = $(this).val();
        var weightFieldName = $(this).data('textfield');
        env_vars.push(variableName);
        weights.push(parseFloat($(`input[name="${weightFieldName}"]`).val()));
    });
    var analysis_period = [];
    analysis_period.push(parseInt($('select[name="start_month"]').val()), parseInt($('select[name="end_month"]').val()));
    var rotation = $('input[name="rot_var"]:checked').val();
    var threshold = $('#threshold').val() / 100;

    var settings = {
        "url": "https://webafsa.cdecentre.org/api/afsa",
        "method": "POST",
        "timeout": 80000,
        "headers": {
            "Content-Type": "application/json"
        },
        "data": JSON.stringify({
            "request_id": request_id,
            "dataset": dataset,
            "longitude": longitude,
            "latitude": latitude,
            "env_vars": env_vars,
            "weights": weights,
            "analysis_period": analysis_period,
            "rotation": rotation,
            "threshold": threshold,
            "rotation_mode": true,
            "threshold_mode": false
        }),
    };

    $.ajax(settings).done(function (response) {
        $('.loader').hide();
        $('#map').show();
        resetMap();

        layer_name = 'afsa:output' + request_id + ',afsa:countries';

        var combinedLayers = L.tileLayer.wms('https://geoserver.cdecentre.org/geoserver/afsa/wms', {
            layers: 'afsa:output' + request_id + ',afsa:countries',
            projection: 'EPSG:4326',
            format: 'image/png',
            transparent: true
        })

        var baseLayers = {
            OpenStreetMap: boundariesLayer,
            AFSA: combinedLayers
        }

        L.control.layers(baseLayers).addTo(map);

        boundariesLayer.addTo(map);

        combinedLayers.addTo(map);

        map.removeLayer(marker);
        
        reference_site_marker = L.marker([latitude, longitude], {icon: greenIcon}).addTo(map);
        reference_site_marker.bindPopup("Reference Site", {closeOnClick: false, autoClose: false}).openPopup();

        $('#compute-sim-div').hide();
        $('#recompute-sim-div').show();
        $('#legend').show();

        map.on('click', function (e) {
            map.removeLayer(marker);
            var new_latlng = e.latlng
            var lat = new_latlng.lat
            var lng = new_latlng.lng
            var WIDTH = map.getSize().x;
            var HEIGHT = map.getSize().y;

            var parameters = {
                request: 'GetFeatureInfo',
                service: 'WMS',
                version: '1.1.1',
                layers: 'afsa:output' + request_id,
                styles: '',
                srs: 'EPSG:4326',
                format: 'image/png',
                bbox: (lng - 0.1) + ',' + (lat - 0.1) + ',' + (lng + 0.1) + ',' + (lat + 0.1),
                width: WIDTH,
                height: HEIGHT,
                query_layers: 'afsa:output' + request_id,
                info_format: 'application/json',
                feature_count: 10,
                x: 50,
                y: 50,

            }
            var url = 'https://geoserver.cdecentre.org/geoserver/afsa/wms' + L.Util.getParamString(parameters)

            var settings2 = {
                "url": url,
                "method": "GET",
                "timeout": 0,
                "headers": {
                    "Content-Type": "application/json"
                }
            };

            $.ajax(settings2).done(function (response) {
                if (new_marker) {
                    map.removeLayer(new_marker)
                }

                var blueIcon = new L.Icon({
                    iconUrl: 'https://raw.githubusercontent.com/pointhi/leaflet-color-markers/master/img/marker-icon-2x-blue.png',
                    shadowUrl: 'https://cdnjs.cloudflare.com/ajax/libs/leaflet/0.7.7/images/marker-shadow.png',
                    iconSize: [25, 41],
                    iconAnchor: [12, 41],
                    popupAnchor: [1, -34],
                    shadowSize: [41, 41]
                  });

                var index = parseFloat(response.features[0].properties.GRAY_INDEX).toFixed(4) * 100;

                new_marker = L.marker(new_latlng, {icon: blueIcon}).addTo(map)

                var popupContent2 = "Similarity Percentage : " + index.toFixed(2) + " %";
                new_marker.bindPopup(popupContent2).openPopup();
            });
        })
    });
});
