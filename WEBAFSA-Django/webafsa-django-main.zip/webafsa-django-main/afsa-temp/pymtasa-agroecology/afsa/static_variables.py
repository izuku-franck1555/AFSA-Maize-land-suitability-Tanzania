import os
import json

script_dir = os.path.dirname(__file__)
config_path = os.path.join(script_dir, "..", "..", "..", "config_server.json")

# Load the config.json file
with open(config_path, 'r') as file:
    config = json.load(file)

TMP_DIRECTORY = config.get("TMP_DIRECTORY")
WORLDCLIM_DIRECTORY = config.get("WORLDCLIM_DIRECTORY")
CHELSA_DIRECTORY = config.get("CHELSA_DIRECTORY")
RESULTS_DIRECTORY = config.get("RESULTS_DIRECTORY")
NORMALIZATION_COEFFICIENTS = {
    'tmean': 10, 'prec': 50, 'tmin': 10, 'tmax': 10, 'bio_1': 10, 'bio_2': 10, 'bio_3': 10, 'bio_4': 10, 'bio_5': 10,
    'bio_6': 10, 'bio_7': 10, 'bio_8': 10, 'bio_9': 10, 'bio_10': 10, 'bio_11': 10, 'bio_12': 10, 'bio_13': 10,
    'bio_14': 10, 'bio_15': 10, 'bio_16': 10, 'bio_17': 10, 'bio_18': 10, 'bio_19': 10
}

# Function to generate file paths
def generate_file_paths(directory, file_names):
    return [os.path.join(directory, file_name) for file_name in file_names]

# File names for monthly data
monthly_data = [f"{data_type}_{month}.tif" for data_type in ["prec", "tavg", "rsds", "wdsp"] for month in ["jan", "feb", "mar", "apr", "may", "jun", "jul", "aug", "sep", "oct", "nov", "dec"]]

# File names for static data
static_data = ["soil_texture.tif", "soil_ph.tif", "slope.tif", "elevation.tif"]

# Generating file paths for WORLDCLIM and CHELSA directories
ENV_DATA_WORLDCLIM = generate_file_paths(WORLDCLIM_DIRECTORY, monthly_data + static_data)
ENV_DATA_CHELSA = generate_file_paths(CHELSA_DIRECTORY, monthly_data + static_data)

# If you need separate lists for each type of data, you can slice ENV_DATA_WORLDCLIM and ENV_DATA_CHELSA
PREC_ENV_DATA_WORLDCLIM = ENV_DATA_WORLDCLIM[0:12]
TAVG_ENV_DATA_WORLDCLIM = ENV_DATA_WORLDCLIM[12:24]
RSDS_ENV_DATA_WORLDCLIM = ENV_DATA_WORLDCLIM[24:36]
WDSP_ENV_DATA_WORLDCLIM = ENV_DATA_WORLDCLIM[36:48]
TEXTURE_ENV_DATA_WORLDCLIM = [ENV_DATA_WORLDCLIM[48]]
PH_ENV_DATA_WORLDCLIM = [ENV_DATA_WORLDCLIM[49]]
SLOPE_ENV_DATA_WORLDCLIM = [ENV_DATA_WORLDCLIM[50]]
ELEVATION_ENV_DATA_WORLDCLIM = [ENV_DATA_WORLDCLIM[51]]

PREC_ENV_DATA_CHELSA = ENV_DATA_CHELSA[0:12]
TAVG_ENV_DATA_CHELSA = ENV_DATA_CHELSA[12:24]
RSDS_ENV_DATA_CHELSA = ENV_DATA_CHELSA[24:36]
WDSP_ENV_DATA_CHELSA = ENV_DATA_CHELSA[36:48]
TEXTURE_ENV_DATA_CHELSA = [ENV_DATA_CHELSA[48]]
PH_ENV_DATA_CHELSA = [ENV_DATA_CHELSA[49]]
SLOPE_ENV_DATA_CHELSA = [ENV_DATA_CHELSA[50]]
ELEVATION_ENV_DATA_CHELSA = [ENV_DATA_CHELSA[51]]
