from afsa.parameters_set import ParametersSet
from afsa.similarity import Similarity
from afsa.utils import Utils
from afsa.static_variables import (RESULTS_DIRECTORY, PREC_ENV_DATA_WORLDCLIM, TAVG_ENV_DATA_WORLDCLIM, RSDS_ENV_DATA_WORLDCLIM,
WDSP_ENV_DATA_WORLDCLIM, TEXTURE_ENV_DATA_WORLDCLIM, PH_ENV_DATA_WORLDCLIM, SLOPE_ENV_DATA_WORLDCLIM, ELEVATION_ENV_DATA_WORLDCLIM, 
PREC_ENV_DATA_CHELSA, TAVG_ENV_DATA_CHELSA, RSDS_ENV_DATA_CHELSA, WDSP_ENV_DATA_CHELSA, TEXTURE_ENV_DATA_CHELSA, PH_ENV_DATA_CHELSA, 
SLOPE_ENV_DATA_CHELSA, ELEVATION_ENV_DATA_CHELSA) 
import os
import json
from geo.Geoserver import Geoserver

script_dir = os.path.dirname(__file__)
config_path = os.path.join(script_dir, "..", "inputs.json")
fp = os.path.join(script_dir, "..", "results", "output.tif")

def get_env_data(dataset_name, inputs):
    if dataset_name == "worldclim":
        static_data = {
            "prec": PREC_ENV_DATA_WORLDCLIM,
            "tmean": TAVG_ENV_DATA_WORLDCLIM,
            "rsds": RSDS_ENV_DATA_WORLDCLIM,
            "wdsp": WDSP_ENV_DATA_WORLDCLIM,
            "texture": TEXTURE_ENV_DATA_WORLDCLIM,
            "ph": PH_ENV_DATA_WORLDCLIM,
            "slope": SLOPE_ENV_DATA_WORLDCLIM,
            "elevation": ELEVATION_ENV_DATA_WORLDCLIM
        }
    else:
        static_data = {
            "prec": PREC_ENV_DATA_CHELSA,
            "tmean": TAVG_ENV_DATA_CHELSA,
            "rsds": RSDS_ENV_DATA_CHELSA,
            "wdsp": WDSP_ENV_DATA_CHELSA,
            "texture": TEXTURE_ENV_DATA_CHELSA,
            "ph": PH_ENV_DATA_CHELSA,
            "slope": SLOPE_ENV_DATA_CHELSA,
            "elevation": ELEVATION_ENV_DATA_CHELSA
        }

    return [static_data[arg] for arg in inputs if arg in static_data]

def get_division_data(inputs):
    static_data = {
        "prec": 12,
        "tmean": 12,
        "rsds": 12,
        "wdsp": 12,
        "texture": 1,
        "ph": 1,
        "slope": 1,
        "elevation": 1
    }

    return tuple([static_data[arg] for arg in inputs if arg in static_data])

if __name__ == '__main__':
    with open(config_path, 'r') as inputs_json_file:
        inputs = json.load(inputs_json_file)

    parameters = ParametersSet(
        longitude=float(inputs['longitude']),
        latitude=float(inputs['latitude']),
        env_vars=tuple(inputs['env_vars']),
        weights=tuple(inputs['weights']),
        number_divisions=get_division_data(inputs['env_vars']),
        env_data_ref=get_env_data(inputs['dataset'], inputs['env_vars']),
        env_data_target=get_env_data(inputs['dataset'], inputs['env_vars']),
        analysis_period=inputs['analysis_period'],
        rotation=inputs['rotation'],
        threshold=float(inputs['threshold']),
        rotation_mode=inputs['rotation_mode'],
        threshold_mode=inputs['threshold_mode'],
        outfile=RESULTS_DIRECTORY,
        file_name="output",
        write_file=True
    )

    similarity = Similarity(parameters)

    raster_file_path = similarity.compute_similarity_raster()

    print("END OF THE SIMILARITY COMPUTATION")

    geo = Geoserver('https://geoserver.cdecentre.org/geoserver', username='admin', password='geoserver')

    print("STEP 1")

    try:
        geo.delete_style(style_name='afsa_style', workspace='afsa')
    except Exception as e:
        print("Hey")
        pass

    print("STEP 2")

    geo.create_coveragestore(layer_name='output' + inputs['request_id'], path=fp, workspace='afsa')

    print("STEP 3")

    geo.create_coveragestyle(raster_path=fp, style_name='afsa_style', workspace='afsa', color_ramp='Spectral')

    print("STEP 4")

    geo.publish_style(layer_name='output' + inputs['request_id'], style_name='afsa_style', workspace='afsa')

    print("STEP 5")








