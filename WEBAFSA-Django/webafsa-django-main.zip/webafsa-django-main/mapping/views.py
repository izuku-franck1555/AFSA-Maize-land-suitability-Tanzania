from django.shortcuts import render
from django.http.request import HttpRequest
from rest_framework.parsers import JSONParser
from django.http.response import JsonResponse
from rest_framework.decorators import api_view
from rest_framework import status
import subprocess 
import os
import json

script_dir = os.path.dirname(__file__)
inputs_path = os.path.join(script_dir, "..", "afsa-temp", "inputs.json")
script_path = os.path.join(script_dir, "..", "afsa_script.sh")
output_file_path = os.path.join(script_dir, "..", "afsa-temp", "results", "output.tif")


@api_view(['POST'])
def analogy(request):
    similarity = []
    if request.method == 'POST':
        data = JSONParser().parse(request)
        if data:
            with open(inputs_path, 'w') as outfile:
                json.dump(data, outfile)
            command = script_path
            subprocess.run(command, shell=True)
            print("STEP 6")
            return JsonResponse(output_file_path, status=status.HTTP_200_OK, safe=False) 
        return JsonResponse("Error", status=status.HTTP_400_BAD_REQUEST)