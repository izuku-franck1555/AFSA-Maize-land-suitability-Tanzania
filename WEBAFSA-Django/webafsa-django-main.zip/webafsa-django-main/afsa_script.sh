#!/bin/bash

# Path to the config.json file
CONFIG_FILE="./config_server.json"

# Extract the PYTHON_PATH and SCRIPT_PATH using jq
PYTHON_PATH=$(jq -r '.PYTHON_PATH' "$CONFIG_FILE")
SCRIPT_PATH=$(jq -r '.SCRIPT_PATH' "$CONFIG_FILE")

# Execute the Python script using the extracted paths
$PYTHON_PATH $SCRIPT_PATH
